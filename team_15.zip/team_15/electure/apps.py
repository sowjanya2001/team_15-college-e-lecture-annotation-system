from django.apps import AppConfig


class ElectureConfig(AppConfig):
    name = 'electure'
