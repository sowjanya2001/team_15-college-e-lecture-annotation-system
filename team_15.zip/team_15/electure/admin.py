from django.contrib import admin
from electure.models import UserProfileInfo
# Register your models here.
admin.site.register(UserProfileInfo)

