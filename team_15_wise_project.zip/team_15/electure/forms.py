from django import forms
from django.contrib.auth.models import User
from electure.models import UserProfileInfo
class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
 
    class Meta():
        model = UserProfileInfo
        fields = ('username','password','email','designation')

class DocumentForm(forms.Form):
    docfile = forms.FileField(
        label='Select a file',
    )
