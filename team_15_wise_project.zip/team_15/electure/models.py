from django.db import models
from django.contrib.auth.models import User
# Create your models here.
types = (('student','Student'),('lecture','Lecture'))
class UserProfileInfo(models.Model):
  username = models.CharField(max_length = 30,default = '')
  password = models.CharField(max_length = 10,default = '')
  email = models.CharField(max_length = 30,default = '@gmail.com')
  designation = models.CharField(max_length=10, choices=types, default='Student')

class Document(models.Model):
    docfile = models.FileField(upload_to='documents/%Y/%m/%d')

