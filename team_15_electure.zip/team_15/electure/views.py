from django.shortcuts import render
from electure.forms import UserForm
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from electure.models import UserProfileInfo
from django.template import RequestContext
from electure.models import Document
from electure.forms import DocumentForm


def index(request):
	return render(request, 'index.html')

def about(request):
	return render(request, 'about.html')

@login_required
def special(request):
    return HttpResponse("You are Logged in !")
def user_logout(request):
    logout(request)
    return render(request, 'index.html')
def welcome(request):
    return render(request,'welcome.html')
def signup(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
        if user_form.is_valid():
            user = user_form.save()
            user.save()
            registered = True
            return render(request, 'welcome.html',
{'user_form':user_form,'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request,'signup.html',{'user_form':user_form,'registered':registered})
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        role = request.POST.get('role')
        user = authenticate(username=username, password=password)
        a = UserProfileInfo.objects.filter(username=username).exists()
        b =UserProfileInfo.objects.filter(password=password).exists()
        if a and b:
                if role == "Student":
                	return HttpResponseRedirect('index')
                else:
                        return HttpResponseRedirect('upload')
            #else:
            #   return HttpResponse("Your account was register in active.")
        else:
            print("Someone tried to Login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request,'user_login.html')
    	
def upload(request):
    # Handle file upload
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            newdoc = Document(docfile = request.FILES['docfile'])
            newdoc.save()

            # Redirect to the document list after POST
            return HttpResponseRedirect(reverse('upload'))
    else:
        form = DocumentForm() # A empty, unbound form

    # Load documents for the list page
    documents = Document.objects.all()

    # Render list page with the documents and the form
    return render(request,'upload.html',
        {'documents': documents, 'form': form},
    )
