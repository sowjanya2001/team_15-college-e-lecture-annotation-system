from django.contrib import admin
from electure.models import UserProfileInfo, Document
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(Document)

