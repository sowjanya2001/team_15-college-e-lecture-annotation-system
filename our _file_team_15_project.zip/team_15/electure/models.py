from django.contrib.auth.models import User
from django.db import models
# Create your models here.
types = (('student','Student'),('lecture','Lecture'))
class UserProfileInfo(models.Model):
  username = models.CharField(max_length = 30,default = '')
  password = models.CharField(max_length = 10,default = '')
  email = models.CharField(max_length = 30,default = '')
  designation = models.CharField(max_length=10, choices=types, default='Student')

class Document(models.Model):
    docfile = models.FileField(upload_to='documents/%Y/%m/%d')

#class Video(models.Model):
 #   name= models.CharField(max_length=500)
  #  description= models.TextField()
   # videofile= models.FileField(upload_to='videos/')

